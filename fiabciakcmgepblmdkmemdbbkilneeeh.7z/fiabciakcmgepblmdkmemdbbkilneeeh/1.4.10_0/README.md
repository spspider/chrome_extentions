# Tab Suspender Chrome Extension

Chrome Store: https://chrome.google.com/webstore/detail/tab-suspender/fiabciakcmgepblmdkmemdbbkilneeeh

Site: https://www.tab-suspender.com/

Automatically suspend, park, hibernate inactive tabs and save up to 80% of memory, reduce load on your device, battery and heat.

If you like to use many open Tabs at once - this extension will help you and automatically accelerate your browser and purge the memory.
	
Extension suspend, park, hibernate inactive tabs and save up to 80% of memory.  

