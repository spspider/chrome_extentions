// SAMPLE
this.i18n = {
    "settings": {
        "en": "<a id='link' target='_blank' class='settings-label' href='https://chrome.google.com/webstore/detail/tab-suspender/fiabciakcmgepblmdkmemdbbkilneeeh' >Tab Suspender</a>"/*,
        "ru": "Настройки"*/
    },
    "search": {
        "en": "Search"/*,
        "ru": "Искать"*/
    },
    "nothing-found": {
        "en": "No matches were found."/*,
        "ru": "Совпадений не найдено."*/
    }
};
